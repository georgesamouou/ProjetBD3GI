import React from 'react'
import './Head.css'
import { FiPlus } from 'react-icons/fi';

const Head = (props) => {
  return (
    <div className='container-fluid text-center head-container'>
      <span>{props.title}</span>
      <span className='float-end px-4'><FiPlus/></span>
    </div>
  )
}

export default Head
