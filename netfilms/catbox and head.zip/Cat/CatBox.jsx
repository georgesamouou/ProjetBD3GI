import React from 'react'
import { SiBookstack } from "react-icons/si";
import './CatBox.css'
const CatBox = ({ title, categories, color }) => {
    const category = categories.map((cat)=>{
        return (
            <div className='CatBox-cat'>cat</div>
        )
    })
    return (
        <div className='CatBox-container' style={{ backgroundColor: color}}/*  style={{backgroundColor:{color}}} */>
            <div className="CatBox-content ">
                <div className='CatBox-title'>{title}</div>
                <div >
                    {category}
                </div>
            </div>
            <div className="CatBox-back">
                <SiBookstack />
            </div>
        </div>
    )
}

export default CatBox
